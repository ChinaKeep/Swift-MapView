//
//  ViewController.swift
//  Swift-MKMapView
//
//  Created by 品德信息 on 2016/12/19.
//  Copyright © 2016年 品德信息. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController ,MKMapViewDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()
        //基础地图
//        self.baseMapView()
        
        //自定义地理视图的地理坐标，为MKMapView指定地理坐标
//        self.myMapView()
        
        //显示地点提示框
//        self.annotationMapView()
        
        //显示地理位置的名称，地理反编码
        self.geocoderMap()
    
        let device  = UIDevice()
        print("divice的信息--%@--%@--%@--%@--%@",device.name,device.systemName,device.systemVersion,device.model,device.localizedModel)
        
    }
    func geocoderMap()  {
        //初始化一个地理位置解析类，使用该类进行地理位置的反向解析
        let geocoder = CLGeocoder()
        //通过设定经纬度来创建一个位置
        let location = CLLocation(latitude:39.9,longitude:116.5)
        //使用地理位置解析对象，解析地理坐标
//        类型别名就是给一个类型定义的一个小名。通过 typealias 关键字进行定义。
//        public typealias CLGeocodeCompletionHandler = ([CLPlacemark]?, Error?) -> Swift.Void
        
        // reverse geocode requests
//        open func reverseGeocodeLocation(_ location: CLLocation, completionHandler: @escaping CoreLocation.CLGeocodeCompletionHandler)
        //@escaping 叫做逃逸闭包 具体详见http://wiki.jikexueyuan.com/project/swift/chapter2/07_Closures.html#closure_expressions

        geocoder.reverseGeocodeLocation(location) { (placeMarks:[CLPlacemark]?, error:Error?) in
        
       //在闭包语句里，处理解析后的结果，当结果中的位置坐标数组，长度大于0时，执行下来的操作
        if(placeMarks?.count)! > 0{
            //获得位置标记数组的第一个元素
            let placeMark = placeMarks?.first
            print(placeMark?.addressDictionary ?? AnyObject.self)
            
        }

        }
     }
    func annotationMapView()  {
        let map = MKMapView(frame:self.view.bounds)
        map.showsUserLocation = true
        map.mapType = MKMapType.satellite
        
        let coordinate2D = CLLocationCoordinate2D(latitude:39.915352,longitude:116.397105)
        let zoomLevel = 0.02//设置地图显示区域的缩放级别
        //初始化一个变量表示地图对象的显示区域
        let regin = MKCoordinateRegionMake(coordinate2D,MKCoordinateSpanMake(zoomLevel, zoomLevel))
        //设置对象的显示区域
        map.setRegion(regin, animated: true)
        self.view.addSubview(map)
        
        let objectAnnotation = MKPointAnnotation()
        //设置注释对象的地理位置
        objectAnnotation.coordinate = coordinate2D;
        //设置注释对象的标题
        objectAnnotation.title = "Imperial Palace"
        //设置注释对象的子标题
        objectAnnotation.subtitle = "China's biggest palace"
        //注释对象添加到地图中
        map.addAnnotation(objectAnnotation)
        

    }
    func myMapView() {
        let map = MKMapView(frame:self.view.bounds)
        map.showsUserLocation = true
        map.mapType = MKMapType.satellite

        let coordinate = CLLocationCoordinate2D(latitude:39.915352,longitude:116.397105)
        let zoomLevel = 0.02//设置地图显示区域的缩放级别
        //初始化一个变量表示地图对象的显示区域
        let regin = MKCoordinateRegionMake(coordinate,MKCoordinateSpanMake(zoomLevel, zoomLevel))
        //设置对象的显示区域
        map.setRegion(regin, animated: true)
        self.view.addSubview(map)
        
        
        
        
    }
    func baseMapView()  {
        
        let map = MKMapView(frame:self.view.bounds)
        map.showsUserLocation = true
        map.mapType = MKMapType.standard
        self.view.addSubview(map)

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

